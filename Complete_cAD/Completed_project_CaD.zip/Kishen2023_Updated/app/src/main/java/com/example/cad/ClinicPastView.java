package com.example.cad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ClinicPastView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clinic_past_view);
    }
}