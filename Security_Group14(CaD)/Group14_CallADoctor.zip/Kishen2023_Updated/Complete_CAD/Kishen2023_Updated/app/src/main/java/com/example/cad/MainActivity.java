package com.example.cad;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cad.utils.EncryptionUtils;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseError;

public class MainActivity extends AppCompatActivity {

    private Button administrator, clinic, doctor, patient, savePasswordButton, loginButton;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the encryption utility
        EncryptionUtils.init(getApplicationContext());

        // Initialize buttons and EditText
        administrator = findViewById(R.id.idBtnSuper);
        clinic = findViewById(R.id.idBtnClinic);
        doctor = findViewById(R.id.idBtnDoctor);
        patient = findViewById(R.id.idBtnPatient);
        passwordEditText = findViewById(R.id.passwordEditText);

        savePasswordButton = findViewById(R.id.savePasswordButton);
        loginButton = findViewById(R.id.loginButton);

        // Set up listeners for roles
        administrator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pro_admin = new Intent(MainActivity.this, AdministratorClinicView.class);
                startActivity(pro_admin);
            }
        });

        clinic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pro_clinic = new Intent(MainActivity.this, ClinicMainView.class);
                startActivity(pro_clinic);
            }
        });

        doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pro_doctor = new Intent(MainActivity.this, DoctorMainView.class);
                startActivity(pro_doctor);
            }
        });

        patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent pro_patient = new Intent(MainActivity.this, PatientMainView.class);
                startActivity(pro_patient);
            }
        });

        // Save encrypted password to Firebase
        savePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveEncryptedPasswordToFirebase();
            }
        });

        // Login by validating the entered password
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    // Method to encrypt the password and save it to Firebase
    private void saveEncryptedPasswordToFirebase() {
        String password = passwordEditText.getText().toString().trim();

        if (!password.isEmpty()) {
            String encryptedPassword = EncryptionUtils.encrypt(password);

            if (encryptedPassword != null) {
                // Log the encrypted password for debugging
                Log.d("EncryptedPassword", encryptedPassword);

                // Save encrypted password to Firebase
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("users");
                String userId = "user123"; // Replace with actual user ID
                myRef.child(userId).child("password").setValue(encryptedPassword);

                Toast.makeText(MainActivity.this, "Password saved securely!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Encryption failed!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please enter a password.", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to login user by encrypting entered password and comparing it with Firebase
    private void loginUser() {
        String inputPassword = passwordEditText.getText().toString().trim();

        if (!inputPassword.isEmpty()) {
            String encryptedInputPassword = EncryptionUtils.encrypt(inputPassword);

            if (encryptedInputPassword != null) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("users/user123/password"); // Path to user password

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        String storedEncryptedPassword = snapshot.getValue(String.class);

                        if (encryptedInputPassword.equals(storedEncryptedPassword)) {
                            Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                            // Proceed with login
                        } else {
                            Toast.makeText(MainActivity.this, "Incorrect password. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(MainActivity.this, "Error fetching password.", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                Toast.makeText(MainActivity.this, "Encryption failed!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please enter a password.", Toast.LENGTH_SHORT).show();
        }
    }
}
